package com.david.fitnesscommandcenter.v2

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "Fitness Command Center & Health Connect"
            textSize = 24f
            setTextColor(Color.rgb(11,31,51))
            setTypeface(typeface, 1)
        }
        val body = TextView(this).apply {
            text = "This app reads only the Health Connect data you choose to share so it can show fitness progress and reports: heart rate, resting heart rate, steps, calories burned, distance, sleep, weight, and exercise sessions.\n\nYour tracking database stays on this phone. Health data is not sold or shared with advertisers. Health data is included in a Gemini progress request only when you explicitly tap an AI insight action.\n\nMicrophone access is separate and is used only when you tap Voice Quick Log. Android speech recognition creates a transcript, then Gemini structures your spoken food/workout entry for your review before anything is saved."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad, 0, pad)
        }
        val button = Button(this).apply {
            text = "Done"
            setOnClickListener { finish() }
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
