package com.david.fitnesscommandcenter.v2

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastSelectedUri: Uri? = null
    private var pendingExportJson: String? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechMode: String = "auto"

    private val prefs by lazy { getSharedPreferences("fcc_secure", Context.MODE_PRIVATE) }
    private val healthClient by lazy { HealthConnectClient.getOrCreate(this) }

    private val healthPermissions: Set<String> by lazy {
        setOf(
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(RestingHeartRateRecord::class),
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
            HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
            HealthPermission.getReadPermission(DistanceRecord::class),
            HealthPermission.getReadPermission(SleepSessionRecord::class),
            HealthPermission.getReadPermission(WeightRecord::class),
            HealthPermission.getReadPermission(ExerciseSessionRecord::class)
        )
    }

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = fileCallback
        fileCallback = null
        if (callback == null) return@registerForActivityResult
        if (result.resultCode != Activity.RESULT_OK) {
            callback.onReceiveValue(null)
            return@registerForActivityResult
        }
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        lastSelectedUri = uris?.firstOrNull()
        callback.onReceiveValue(uris)
    }

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechRecognition_() else sendResult(JSONObject().put("kind", "speech_error").put("message", "Microphone permission was not granted."))
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            sendResult(JSONObject().put("kind", "backup_import").put("data", text))
        } catch (e: Exception) {
            sendError("Backup import failed: ${e.message}")
        }
    }

    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val data = pendingExportJson
        pendingExportJson = null
        if (uri == null || data == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(StandardCharsets.UTF_8)) }
            sendResult(JSONObject().put("kind", "backup_export").put("ok", true))
        } catch (e: Exception) {
            sendError("Backup export failed: ${e.message}")
        }
    }

    private val healthPermissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        val ok = granted.containsAll(healthPermissions)
        sendResult(JSONObject().put("kind", "health_permissions").put("granted", ok))
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = true
            addJavascriptInterface(AndroidBridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme == "http" || uri.scheme == "https") {
                        openExternal_(uri.toString())
                        return true
                    }
                    return false
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = filePathCallback
                    val intent = try {
                        fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "image/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                    } catch (_: Exception) {
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "image/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                    }
                    filePicker.launch(intent)
                    return true
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        scope.cancel()
        webView.removeJavascriptInterface("Android")
        webView.destroy()
        super.onDestroy()
    }

    inner class AndroidBridge {
        @JavascriptInterface fun hasApiKey(): Boolean = getApiKey_().isNotBlank()
        @JavascriptInterface fun getModel(): String = prefs.getString("model", "gemini-3.5-flash-lite") ?: "gemini-3.5-flash-lite"
        @JavascriptInterface fun setModel(model: String) { prefs.edit().putString("model", model.trim().ifBlank { "gemini-3.5-flash-lite" }).apply() }
        @JavascriptInterface fun setApiKey(key: String) {
            try { prefs.edit().putString("gemini_key", encrypt_(key.trim())).apply() }
            catch (e: Exception) { sendError("Could not securely save API key: ${e.message}") }
        }
        @JavascriptInterface fun testGemini() { scope.launch { testGemini_() } }
        @JavascriptInterface fun analyzeLastImage(mealType: String) { scope.launch { analyzeImage_(mealType) } }
        @JavascriptInterface fun generateInsight(summary: String) { scope.launch { generateInsight_(summary) } }
        @JavascriptInterface fun generateReport(request: String) { scope.launch { generateReport_(request) } }
        @JavascriptInterface fun researchExercise(name: String) { scope.launch { researchExercise_(name) } }
        @JavascriptInterface fun researchVideo(id: String, name: String) { scope.launch { researchVideo_(id, name) } }
        @JavascriptInterface fun openExternal(url: String) { runOnUiThread { openExternal_(url) } }
        @JavascriptInterface fun exportBackup(json: String) {
            pendingExportJson = json
            runOnUiThread { exportBackupLauncher.launch("Fitness_Command_Center_Backup_${LocalDate.now()}.json") }
        }
        @JavascriptInterface fun importBackup() { runOnUiThread { importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) } }

        @JavascriptInterface fun startVoiceInput(mode: String) {
            speechMode = mode.ifBlank { "auto" }
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startSpeechRecognition_()
                else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        @JavascriptInterface fun parseVoiceLog(transcript: String, mode: String) { scope.launch { parseVoiceLog_(transcript, mode) } }

        @JavascriptInterface fun healthConnectAvailable(): Boolean = healthStatus_() == HealthConnectClient.SDK_AVAILABLE
        @JavascriptInterface fun requestHealthPermissions() { requestHealthPermissions_() }
        @JavascriptInterface fun readHealthToday() { scope.launch { readHealthDate_(LocalDate.now()) } }
        @JavascriptInterface fun readHealthDate(date: String) {
            scope.launch {
                try { readHealthDate_(LocalDate.parse(date)) }
                catch (_: Exception) { sendResult(JSONObject().put("kind", "health_error").put("message", "Invalid health date.")) }
            }
        }
        @JavascriptInterface fun openHealthConnectSettings() { runOnUiThread { openHealthSettings_() } }
    }

    private fun startSpeechRecognition_() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendResult(JSONObject().put("kind", "speech_error").put("message", "Android speech recognition is not available on this device."))
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { sendResult(JSONObject().put("kind", "speech_partial").put("text", "Listening…")) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { sendResult(JSONObject().put("kind", "speech_partial").put("text", "Processing speech…")) }
            override fun onError(error: Int) {
                sendResult(JSONObject().put("kind", "speech_error").put("message", speechErrorText_(error)))
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) sendResult(JSONObject().put("kind", "speech_error").put("message", "I did not catch that. Try speaking again."))
                else sendResult(JSONObject().put("kind", "speech_transcript").put("text", text).put("mode", speechMode))
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) sendResult(JSONObject().put("kind", "speech_partial").put("text", text))
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell me what you ate or what exercise you completed")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun speechErrorText_(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_CLIENT -> "Speech recognition stopped."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required for Voice Quick Log."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition network error."
        SpeechRecognizer.ERROR_NO_MATCH -> "I could not understand that. Try again with the food/exercise and numbers."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Try again in a moment."
        SpeechRecognizer.ERROR_SERVER -> "Speech recognition service error. Try again."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech was detected. Tap the microphone and try again."
        else -> "Speech recognition error ($code)."
    }

    private suspend fun parseVoiceLog_(transcript: String, mode: String) {
        try {
            requireApiKey_()
            val prompt = """
                You are the structured voice logger inside a personal fitness, nutrition, speed, agility, and strength tracking app.
                Today is ${LocalDate.now()}.
                User mode hint: $mode.
                The user's spoken transcript is:
                \"$transcript\"

                Convert ONLY what the user said into a proposed log. Do not invent completed exercises or foods that were not mentioned.
                Resolve common exercise-name variants to normal names (for example, \"RDL\" -> \"Romanian Deadlift\") when clear.
                For workouts, extract sets, reps, weight in pounds, duration, cardio minutes, distance, sprint/agility time, RPE, recovery, and calories burned when explicitly spoken. Unknown numeric fields must be 0. Do not invent calories burned; leave calories_burned_kcal as 0 unless the user stated it.
                For meals, identify foods and portions. If nutrition values were not spoken, estimate calories, protein, carbs, fat and fiber from the stated foods/portions. If portions were vague, use a reasonable typical serving and lower confidence; explain assumptions in notes.
                Water should be converted to ounces. If liters are spoken, convert to ounces.
                Body/recovery may include weight, sleep hours, energy score 1-10, or resting heart rate.
                If the transcript includes multiple exercises from one workout, place them in one workout_session so they share one session ID when saved.
                Return JSON only matching the supplied schema. The user will review the result before it is saved.
            """.trimIndent()
            val resultText = generateStructured_(prompt, voiceSchema_())
            val parsed = parseJsonLoose_(resultText)
            sendResult(JSONObject().put("kind", "voice_parsed").put("data", parsed).put("transcript", transcript))
        } catch (e: Exception) {
            sendResult(JSONObject().put("kind", "speech_error").put("message", "Gemini could not structure that voice log: ${e.message}"))
        }
    }

    private fun voiceSchema_(): JSONObject = JSONObject("""
      {
        "type":"OBJECT",
        "properties":{
          "intent":{"type":"STRING"},
          "date":{"type":"STRING"},
          "summary":{"type":"STRING"},
          "confidence":{"type":"NUMBER"},
          "meals":{"type":"ARRAY","items":{"type":"OBJECT","properties":{
            "food_name":{"type":"STRING"},"meal_type":{"type":"STRING"},"serving_size":{"type":"STRING"},
            "calories":{"type":"NUMBER"},"protein_g":{"type":"NUMBER"},"carbs_g":{"type":"NUMBER"},"fat_g":{"type":"NUMBER"},"fiber_g":{"type":"NUMBER"},"confidence":{"type":"NUMBER"},"notes":{"type":"STRING"}
          },"required":["food_name","meal_type","serving_size","calories","protein_g","carbs_g","fat_g","fiber_g","confidence","notes"]}},
          "workout_session":{"type":"OBJECT","properties":{
            "workout_type":{"type":"STRING"},"duration_min":{"type":"NUMBER"},"cardio_min":{"type":"NUMBER"},"calories_burned_kcal":{"type":"NUMBER"},"notes":{"type":"STRING"},
            "exercises":{"type":"ARRAY","items":{"type":"OBJECT","properties":{
              "exercise":{"type":"STRING"},"category":{"type":"STRING"},"sets":{"type":"NUMBER"},"reps":{"type":"NUMBER"},"weight_lb":{"type":"NUMBER"},
              "distance_yards":{"type":"NUMBER"},"distance_miles":{"type":"NUMBER"},"time_seconds":{"type":"NUMBER"},"rpe":{"type":"NUMBER"},"recovery_seconds":{"type":"NUMBER"},
              "metric_name":{"type":"STRING"},"metric_value":{"type":"NUMBER"},"metric_unit":{"type":"STRING"},"notes":{"type":"STRING"}
            },"required":["exercise","category","sets","reps","weight_lb","distance_yards","distance_miles","time_seconds","rpe","recovery_seconds","metric_name","metric_value","metric_unit","notes"]}}
          },"required":["workout_type","duration_min","cardio_min","calories_burned_kcal","notes","exercises"]},
          "water_oz":{"type":"NUMBER"},
          "body":{"type":"OBJECT","properties":{"weight_lb":{"type":"NUMBER"},"sleep_hours":{"type":"NUMBER"},"energy_score":{"type":"NUMBER"},"resting_hr_bpm":{"type":"NUMBER"}},"required":["weight_lb","sleep_hours","energy_score","resting_hr_bpm"]}
        },
        "required":["intent","date","summary","confidence","meals","workout_session","water_oz","body"]
      }
    """.trimIndent())

    private fun requestHealthPermissions_() {
        if (healthStatus_() != HealthConnectClient.SDK_AVAILABLE) {
            sendResult(JSONObject().put("kind", "health_error").put("message", "Health Connect is not available on this device."))
            return
        }
        scope.launch {
            try {
                val granted = healthClient.permissionController.getGrantedPermissions()
                if (granted.containsAll(healthPermissions)) {
                    sendResult(JSONObject().put("kind", "health_permissions").put("granted", true))
                } else {
                    runOnUiThread { healthPermissionLauncher.launch(healthPermissions) }
                }
            } catch (e: Exception) {
                sendResult(JSONObject().put("kind", "health_error").put("message", "Health Connect permission check failed: ${e.message}"))
            }
        }
    }

    private suspend fun readHealthDate_(targetDate: LocalDate) {
        if (healthStatus_() != HealthConnectClient.SDK_AVAILABLE) {
            sendResult(JSONObject().put("kind", "health_error").put("message", "Health Connect is not available.")); return
        }
        try {
            val granted = healthClient.permissionController.getGrantedPermissions()
            if (!granted.containsAll(healthPermissions)) {
                withContext(Dispatchers.Main) { healthPermissionLauncher.launch(healthPermissions) }
                return
            }

            val zone = ZoneId.systemDefault()
            val start = targetDate.atStartOfDay(zone).toInstant()
            val now = Instant.now()
            val todayLocal = LocalDate.now(zone)
            val end = if (targetDate == todayLocal) now else targetDate.plusDays(1).atStartOfDay(zone).toInstant()
            if (start.isAfter(now)) {
                sendResult(JSONObject().put("kind", "health_error").put("message", "Health data cannot be read for a future date.")); return
            }
            val previousDay = start.minus(Duration.ofHours(18))
            val weightStart = start.minus(Duration.ofDays(90))

            val hrRecords = healthClient.readRecords(ReadRecordsRequest(HeartRateRecord::class, TimeRangeFilter.between(start, end))).records
            val latestSample = hrRecords.flatMap { it.samples }.maxByOrNull { it.time }
            val latestHr = latestSample?.beatsPerMinute ?: 0L

            val restingRecords = healthClient.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, TimeRangeFilter.between(start, end))).records
            val restingHr = restingRecords.maxByOrNull { it.time }?.beatsPerMinute ?: 0L

            val aggregation = healthClient.aggregate(
                AggregateRequest(
                    metrics = setOf(
                        StepsRecord.COUNT_TOTAL,
                        ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                        TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                        DistanceRecord.DISTANCE_TOTAL,
                        HeartRateRecord.BPM_AVG,
                        HeartRateRecord.BPM_MIN,
                        HeartRateRecord.BPM_MAX
                    ),
                    timeRangeFilter = TimeRangeFilter.between(start, end)
                )
            )
            val steps = aggregation[StepsRecord.COUNT_TOTAL] ?: 0L
            val activeCalories = aggregation[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
            val totalCalories = aggregation[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0
            val distanceMiles = aggregation[DistanceRecord.DISTANCE_TOTAL]?.inMiles ?: 0.0
            val averageHr = aggregation[HeartRateRecord.BPM_AVG] ?: 0L
            val minHr = aggregation[HeartRateRecord.BPM_MIN] ?: 0L
            val maxHr = aggregation[HeartRateRecord.BPM_MAX] ?: 0L

            val sleepRecords = healthClient.readRecords(ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(previousDay, end))).records
            val sleepSeconds = sleepRecords.sumOf { r ->
                val ss = if (r.startTime.isBefore(previousDay)) previousDay else r.startTime
                val ee = if (r.endTime.isAfter(end)) end else r.endTime
                if (ee.isAfter(ss)) Duration.between(ss, ee).seconds else 0L
            }
            val sleepHours = sleepSeconds / 3600.0

            val weightRecords = healthClient.readRecords(ReadRecordsRequest(WeightRecord::class, TimeRangeFilter.between(weightStart, end))).records
            val weightLb = weightRecords.maxByOrNull { it.time }?.weight?.inPounds ?: 0.0

            val exerciseRecords = healthClient.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, TimeRangeFilter.between(start, end))).records
            val exerciseDetails = JSONArray()
            for (record in exerciseRecords.sortedBy { it.startTime }) {
                val sessionStart = if (record.startTime.isBefore(start)) start else record.startTime
                val sessionEnd = if (record.endTime.isAfter(end)) end else record.endTime
                var sessionAvgHr = 0L
                var sessionActiveCalories = 0.0
                if (sessionEnd.isAfter(sessionStart)) {
                    val sessionAgg = healthClient.aggregate(
                        AggregateRequest(
                            metrics = setOf(
                                ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                                HeartRateRecord.BPM_AVG
                            ),
                            timeRangeFilter = TimeRangeFilter.between(sessionStart, sessionEnd)
                        )
                    )
                    sessionAvgHr = sessionAgg[HeartRateRecord.BPM_AVG] ?: 0L
                    sessionActiveCalories = sessionAgg[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
                }
                exerciseDetails.put(
                    JSONObject()
                        .put("start_time", record.startTime.toString())
                        .put("end_time", record.endTime.toString())
                        .put("duration_min", round2_(Duration.between(record.startTime, record.endTime).seconds / 60.0))
                        .put("title", record.title ?: "")
                        .put("notes", record.notes ?: "")
                        .put("exercise_type", record.exerciseType)
                        .put("average_heart_rate_bpm", sessionAvgHr)
                        .put("active_calories_kcal", round2_(sessionActiveCalories))
                        .put("source_package", record.metadata.dataOrigin.packageName)
                )
            }

            val hrSources = JSONArray()
            hrRecords.map { it.metadata.dataOrigin.packageName }.filter { it.isNotBlank() }.distinct().forEach { hrSources.put(it) }

            val data = JSONObject()
                .put("date", targetDate.toString())
                .put("latest_heart_rate_bpm", latestHr)
                .put("average_heart_rate_bpm", averageHr)
                .put("min_heart_rate_bpm", minHr)
                .put("max_heart_rate_bpm", maxHr)
                .put("resting_hr_bpm", restingHr)
                .put("steps", steps)
                .put("active_calories_kcal", round2_(activeCalories))
                .put("total_calories_kcal", round2_(totalCalories))
                .put("distance_miles", round2_(distanceMiles))
                .put("sleep_hours", round2_(sleepHours))
                .put("weight_lb", round2_(weightLb))
                .put("exercise_sessions", exerciseRecords.size)
                .put("exercise_sessions_detail", exerciseDetails)
                .put("heart_rate_sources", hrSources)
                .put("source_label", "Health Connect")
            sendResult(JSONObject().put("kind", "health_data").put("data", data))
        } catch (e: Exception) {
            sendResult(JSONObject().put("kind", "health_error").put("message", "Could not read Health Connect: ${e.message}"))
        }
    }

    private fun healthStatus_(): Int = try { HealthConnectClient.getSdkStatus(this) } catch (_: Exception) { HealthConnectClient.SDK_UNAVAILABLE }

    private fun openHealthSettings_() {
        try {
            startActivity(Intent("android.health.connect.action.HEALTH_HOME_SETTINGS"))
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }
    }

    private suspend fun analyzeImage_(mealType: String) {
        try {
            requireApiKey_()
            val uri = lastSelectedUri ?: throw IllegalStateException("Choose a meal image first.")
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("Could not read the selected image.")
            if (bytes.size > 15 * 1024 * 1024) throw IllegalStateException("Image is larger than 15 MB.")
            val mime = contentResolver.getType(uri) ?: "image/jpeg"
            val prompt = """
                Analyze this one meal image for a personal nutrition log. Meal type: $mealType.
                Identify visible food/drink items, estimate practical portions, and estimate TOTAL calories, protein g, carbs g, fat g and fiber g.
                Return a confidence score 0.00-1.00 and a concise explanation of assumptions. These are estimates, not exact label values.
                Return JSON only matching the schema.
            """.trimIndent()
            val payload = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))))
                .put(JSONObject().put("text", prompt))
            ))).put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("responseSchema", mealSchema_()))
            val text = postGemini_(payload)
            sendResult(JSONObject().put("kind", "meal").put("data", parseJsonLoose_(text)))
        } catch (e: Exception) { sendError("Meal analysis failed: ${e.message}") }
    }

    private fun mealSchema_(): JSONObject = JSONObject("""
      {"type":"OBJECT","properties":{
        "estimated_foods":{"type":"ARRAY","items":{"type":"STRING"}},
        "estimated_calories":{"type":"NUMBER"},"estimated_protein_g":{"type":"NUMBER"},"estimated_carbs_g":{"type":"NUMBER"},"estimated_fat_g":{"type":"NUMBER"},"estimated_fiber_g":{"type":"NUMBER"},
        "confidence":{"type":"NUMBER"},"short_explanation":{"type":"STRING"}
      },"required":["estimated_foods","estimated_calories","estimated_protein_g","estimated_carbs_g","estimated_fat_g","estimated_fiber_g","confidence","short_explanation"]}
    """.trimIndent())

    private suspend fun generateInsight_(summary: String) {
        try {
            val prompt = """
              You are a practical fitness and baseball-performance tracking assistant. Review the following LOCAL tracking summary.
              Give a concise report with: (1) progress highlights, (2) consistency/adherence, (3) speed/agility/strength performance observations when data exists, (4) nutrition/hydration observations, (5) Health Connect heart-rate/steps/sleep observations when data exists, and (6) 3 practical next-week adjustments.
              Do not diagnose medical conditions. Do not invent missing data. Keep it under 500 words.
              DATA: $summary
            """.trimIndent()
            val text = generateText_(prompt)
            sendResult(JSONObject().put("kind", "insight").put("text", text))
        } catch (e: Exception) { sendError("AI insight failed: ${e.message}") }
    }


    private suspend fun generateReport_(request: String) {
        try {
            requireApiKey_()
            val req = JSONObject(request)
            val reportType = req.optString("report_type", "daily").lowercase(Locale.US)
            val label = req.optString("label", "Gemini Fitness Report")
            val startDate = req.optString("start_date", "")
            val endDate = req.optString("end_date", "")
            val requestId = req.optString("request_id", "")
            val auto = req.optBoolean("auto", false)
            val data = req.optJSONObject("data") ?: JSONObject()
            val maxWords = when (reportType) {
                "daily" -> 450
                "weekly" -> 700
                else -> 900
            }
            val nextLabel = when (reportType) {
                "daily" -> "tomorrow / the next training day"
                "weekly" -> "the next 7 days"
                else -> "the next month"
            }
            val prompt = """
              You are the coaching-report engine inside a private personal Fitness Command Center app.
              Generate a ${reportType.uppercase(Locale.US)} report titled: $label.
              Analyze ONLY the supplied tracking data. It may include meals/macros, workouts/exercises/sets/reps/load/performance results, water, habits, body/recovery, Health Connect / Pixel Watch average-resting-min-max heart rate, steps, sleep, active/total calories burned, distance, weight and prior-period comparison data.

              Use these sections in this order:
              OVERVIEW
              WHAT WENT WELL
              WHAT COULD BE BETTER
              TRAINING & PERFORMANCE
              NUTRITION
              HYDRATION
              HEART RATE & RECOVERY
              FOCUS FOR $nextLabel

              Requirements:
              - Use concrete numbers from the data whenever useful.
              - Compare with goals and the previous comparable period when the data supports it.
              - Mention meaningful consistency, personal bests, training volume and adherence when present.
              - For meals, discuss overall calories/macros/fiber and meal patterns without inventing foods or exact nutrient values.
              - Keep calories eaten separate from active calories burned and total calories burned. Do not claim a precise energy deficit/surplus from wearable estimates.
              - Treat heart-rate and wearable data as fitness/recovery observations only. Do not diagnose medical conditions or make alarmist claims. If data is missing, say that it was not logged/synced rather than guessing.
              - Do not recommend crash dieting, dehydration, unsafe training volume, or compensating for food with exercise.
              - End with 3-5 specific, practical actions for the next period.
              - Keep the report readable on a phone and under $maxWords words.

              TRACKING DATA:
              ${data.toString()}
            """.trimIndent()
            val text = generateText_(prompt)
            sendResult(
                JSONObject()
                    .put("kind", "period_report")
                    .put("request_id", requestId)
                    .put("report_type", reportType)
                    .put("label", label)
                    .put("start_date", startDate)
                    .put("end_date", endDate)
                    .put("auto", auto)
                    .put("text", text)
            )
        } catch (e: Exception) {
            sendResult(JSONObject().put("kind", "report_error").put("message", "Gemini report failed: ${e.message}"))
        }
    }

    private suspend fun researchExercise_(name: String) {
        try {
            val prompt = """
              Use Google Search to research the exercise named \"$name\" for a baseball/speed/agility/strength training library.
              Return ONE JSON object only with keys: name, category, purpose, why_it_matters, form_instructions, common_mistakes, suggested_sets_reps, rest_progression, equipment, difficulty, best_use, youtube_url, primary_metric, unit, better_direction.
              Prefer a direct, reputable YouTube demonstration URL when one can be verified. Do not fabricate a video URL. If no reliable direct YouTube URL is found, use an empty string.
            """.trimIndent()
            val x = researchJson_(prompt)
            sendResult(JSONObject().put("kind", "exercise").put("data", x))
        } catch (e: Exception) { sendError("Exercise research failed: ${e.message}") }
    }

    private suspend fun researchVideo_(id: String, name: String) {
        try {
            val prompt = """
              Use Google Search to find a current, reputable YouTube demonstration for the exercise \"$name\".
              Prefer a coaching/strength-and-conditioning source with a clear demonstration. Return JSON only: {"youtube_url":"direct https://www.youtube.com/watch?v=... URL or empty string","title":"video title","note":"short reason"}.
              Never invent a URL.
            """.trimIndent()
            val x = researchJson_(prompt)
            sendResult(JSONObject().put("kind", "video").put("id", id).put("data", x))
        } catch (e: Exception) { sendError("Video research failed: ${e.message}") }
    }

    private suspend fun testGemini_() {
        try {
            requireApiKey_()
            val text = generateStructured_("Return JSON only: {\"ok\":true}", JSONObject("""{"type":"OBJECT","properties":{"ok":{"type":"BOOLEAN"}},"required":["ok"]}"""))
            val ok = parseJsonLoose_(text).optBoolean("ok", false)
            sendResult(JSONObject().put("kind", "test").put("ok", ok).put("model", currentModel_()))
        } catch (e: Exception) {
            sendResult(JSONObject().put("kind", "test").put("ok", false).put("error", e.message ?: "Unknown error").put("model", currentModel_()))
        }
    }

    private suspend fun generateText_(prompt: String): String {
        requireApiKey_()
        val payload = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        return postGemini_(payload)
    }

    private suspend fun generateStructured_(prompt: String, schema: JSONObject): String {
        requireApiKey_()
        val payload = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("responseSchema", schema))
        return postGemini_(payload)
    }

    private suspend fun researchJson_(prompt: String): JSONObject {
        requireApiKey_()
        val payload = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val text = postGemini_(payload)
        return parseJsonLoose_(text)
    }

    private suspend fun postGemini_(payload: JSONObject): String = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/${Uri.encode(currentModel_())}:generateContent"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30000
            readTimeout = 70000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", getApiKey_())
        }
        connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = BufferedReader(InputStreamReader(stream ?: throw IllegalStateException("No Gemini response"), StandardCharsets.UTF_8)).use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("HTTP $code: ${raw.take(900)}")
        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates") ?: throw IllegalStateException("Gemini returned no candidates")
        if (candidates.length() == 0) throw IllegalStateException("Gemini returned no candidates")
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: throw IllegalStateException("Gemini returned no content")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        val text = sb.toString().trim()
        if (text.isBlank()) throw IllegalStateException("Gemini returned an empty response")
        text
    }

    private fun parseJsonLoose_(text: String): JSONObject {
        var s = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a >= 0 && b > a) s = s.substring(a, b + 1)
        return JSONObject(s)
    }

    private fun currentModel_(): String = prefs.getString("model", "gemini-3.5-flash-lite")?.trim().orEmpty().ifBlank { "gemini-3.5-flash-lite" }
    private fun requireApiKey_() { if (getApiKey_().isBlank()) throw IllegalStateException("Add your Gemini API key in Settings first.") }
    private fun getApiKey_(): String {
        val encrypted = prefs.getString("gemini_key", "") ?: ""
        if (encrypted.isBlank()) return ""
        return try { decrypt_(encrypted) } catch (_: Exception) { "" }
    }

    private fun getSecretKey_(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return gen.generateKey()
    }

    private fun encrypt_(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey_())
        val encrypted = cipher.doFinal(plain.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt_(blob: String): String {
        val all = Base64.decode(blob, Base64.NO_WRAP)
        val iv = all.copyOfRange(0, 12)
        val data = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey_(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), StandardCharsets.UTF_8)
    }

    private fun openExternal_(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
    }

    private fun sendError(message: String) = sendResult(JSONObject().put("kind", "error").put("message", message))
    private fun sendResult(obj: JSONObject) {
        val encoded = JSONObject.quote(obj.toString())
        runOnUiThread {
            if (::webView.isInitialized) webView.evaluateJavascript("window.onNativeResult($encoded);", null)
        }
    }

    private fun round2_(x: Double): Double = kotlin.math.round(x * 100.0) / 100.0

    companion object { private const val KEY_ALIAS = "fcc_gemini_api_key_v2" }
}
